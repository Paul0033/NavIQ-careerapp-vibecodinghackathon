# NavIQ - Student Edition

## Overview

NavIQ is a comprehensive web application designed to help students navigate their careers intelligently. The platform provides smart tools for resume optimization, job search strategy, and career development. The application provides tools for resume analysis, ATS (Applicant Tracking System) optimization, job application tailoring, networking outreach generation, and career planning. Built as a full-stack TypeScript application, it combines a React frontend with an Express.js backend, featuring a modern glass-morphism dark theme UI and client-side resume processing capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state and custom hooks for local storage
- **UI Components**: Shadcn/ui component library with Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom CSS variables for theming, featuring a glass-morphism dark theme with gradient backgrounds
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database ORM**: Drizzle ORM configured for PostgreSQL with schema-first development
- **Database**: PostgreSQL with Neon serverless database integration
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **Development**: Hot module replacement and runtime error overlay for enhanced developer experience

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless platform for scalable, managed database hosting
- **Local Storage**: Browser localStorage for client-side data persistence and user preferences
- **Session Storage**: PostgreSQL-backed sessions for user authentication state
- **File Processing**: Client-side only resume parsing with no server uploads for privacy

### Authentication and Authorization
- **Session-based Authentication**: Traditional cookie-based sessions stored in PostgreSQL
- **User Schema**: Simple username/password model with UUID primary keys
- **Password Security**: Implementation ready for password hashing (not yet implemented)
- **Storage Interface**: Abstracted storage layer with both memory and database implementations

### External Dependencies
- **Resume Processing Libraries**:
  - PDF.js for client-side PDF text extraction
  - Mammoth.js for DOCX document parsing
  - Native FileReader API for text file processing
- **PDF Generation**: jsPDF for client-side resume PDF creation
- **Date Handling**: date-fns for robust date manipulation
- **Form Validation**: React Hook Form with Zod schema validation via Hookform/resolvers
- **UI Animations**: Embla Carousel for interactive carousels and smooth transitions

### Key Features and Capabilities
- **Resume Import and Analysis**: Client-side parsing of PDF, DOCX, and TXT files with automatic data extraction
- **ATS Optimization**: Real-time scoring algorithm for resume bullet points based on industry best practices
- **Job Tailoring**: Keyword matching and bullet point enhancement based on job descriptions
- **Career Planning**: Role-specific 7-day action plans with templates for different career tracks
- **Networking Tools**: Automated outreach message generation for various communication channels
- **Portfolio Management**: Project showcase tools with impact highlighting
- **Profile Management**: Multiple profile system for different job applications
- **PDF Export**: Client-side resume generation with professional formatting

The application follows a component-based architecture with clear separation of concerns, utilizing modern React patterns and TypeScript for maintainability. The glass-morphism design system provides a cohesive visual experience while maintaining accessibility standards through Radix UI components.